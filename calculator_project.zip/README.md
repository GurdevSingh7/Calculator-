# Web Calculator

A simple calculator web app using HTML, CSS, and JavaScript.

## Features
- Basic operations: +, −, ×, ÷
- Clean UI
- Responsive buttons

## Screenshot
![calculator preview](https://via.placeholder.com/300x200.png?text=Calculator+Preview)

## Created by
**Gurdev Singh**  
B.Tech CSE | 1st Year | JCDM College of Engineering, Sirsa
